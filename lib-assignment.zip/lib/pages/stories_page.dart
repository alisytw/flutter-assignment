import 'package:flutter/material.dart';
import '/widgets/story_widget.dart';

class StoriesPage extends StatelessWidget {
  const StoriesPage({super.key});

  @override
  Widget build(BuildContext context) {
    if (MediaQuery.of(context).size.width < 1024) {
      return Scaffold(
        floatingActionButton: FloatingActionButton(
          onPressed: () => {},
          backgroundColor: Colors.transparent,
          child: Image.asset(
            'icons/heart.png',
            scale: 2,
            color: Colors.white,
          ),
        ),
        body: Stack(
          children: [
            Container(
              width: double.infinity,
              height: double.infinity,
              child: Image.asset(
                'imgs/post/1a2ea942da4114f0af70a14429e75594.png',
                fit: BoxFit.cover,
              ),
            ),
            Padding(
              padding: EdgeInsets.only(top: 400, left: 50),
              child: Container(
                width: 128,
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(Radius.circular(99))),
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image.asset(
                        'icons/tag_purple.png',
                        scale: 2,
                      ),
                      SizedBox(
                        width: 4,
                      ),
                      Text(
                        'Meditation',
                        style: TextStyle(color: Colors.purple.shade800),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Column(
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                            vertical: 8.0, horizontal: 4),
                        child: Container(
                          height: 4,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.all(Radius.circular(99)),
                            color: Colors.grey.withOpacity(0.5),
                          ),
                        ),
                      ),
                    ),
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                            vertical: 8.0, horizontal: 4),
                        child: Container(
                          height: 4,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.all(Radius.circular(99)),
                            color: Colors.grey.withOpacity(0.5),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          SizedBox(
                            width: 48,
                            height: 48,
                            child: MaterialButton(
                              shape: RoundedRectangleBorder(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(8))),
                              onPressed: () => Navigator.pop(context),
                              child: Image.asset(
                                'icons/arrow_left_purple.png',
                                scale: 2,
                              ),
                              color: Colors.white,
                            ),
                          ),
                          SizedBox(
                            width: 8,
                          ),
                          Text(
                            'Maria Dl Valio',
                            style: TextStyle(color: Colors.white),
                          ),
                          SizedBox(
                            width: 8,
                          ),
                          Text(
                            '17m',
                            style: TextStyle(color: Colors.white54),
                          )
                        ],
                      ),
                      Image.asset(
                        'icons/download.png',
                        scale: 2,
                      ),
                    ],
                  ),
                )
              ],
            ),
          ],
        ),
      );
    } else {
      return Scaffold(
        backgroundColor: Colors.grey.shade900,
        body: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(
              padding: EdgeInsets.symmetric(vertical: 48),
              child: Container(
                width: 260,
              ),
            ),
            SizedBox(
              width: 8,
            ),
            Container(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.grey.shade200.withOpacity(0.5),
              ),
              width: 48,
              height: 48,
              child: Icon(Icons.arrow_back_ios_new),
            ),
            SizedBox(
              width: 8,
            ),
            Container(
              width: 300,
              child: StoryWidget(
                imgPath: 'imgs/stories/74aebe16a4ba91205ed6da4f5038fc96.jpg',
              ),
            ),
            SizedBox(
              width: 8,
            ),
            Container(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.grey.shade200.withOpacity(0.5),
              ),
              width: 48,
              height: 48,
              child: Icon(Icons.arrow_forward_ios),
            ),
            SizedBox(
              width: 8,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 48),
              child: Container(
                width: 260,
                child: StoryWidget(
                  imgPath: 'imgs/stories/ba54a0926b720ae70cffa6cc4b1ac6df.jpg',
                ),
              ),
            ),
          ],
        ),
      );
    }
  }
}
